import SwiftUI
import UIKit
import Foundation
import CryptoKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var keySession = SupabaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = AppSection.installed.rawValue
        } else {
            initialTab = AppSection.home.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: AppSection.installed.rawValue))
#endif
    }

    var body: some View {
        Group {
            if keySession.isAuthorized {
                if keySession.selectedMode != nil {
                    if horizontalSizeClass == .regular {
                        regularLayout
                    } else {
                        compactLayout
                    }
                } else {
                    FirebaseAuraModeSelectionView { mode in
                        keySession.selectMode(mode)
                    }
                }
            } else {
                FirebaseKeyActivationView { key in
                    await keySession.activate(key)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await keySession.restore() }
        }
        .task {
            await keySession.restore()
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
        .tint(Color(red: 0.95, green: 0.12, blue: 0.16))
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Fax Aura")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .installed
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .installed: return "tab.installed"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .installed: return "tray.and.arrow.down.fill"
        }
    }
}


private enum FaxAuraMode: String {
    case normal = "normal"

    var title: String { "Normal" }
    var subtitle: String { "Stable Free Fire profile" }
    var icon: String { "flame.fill" }
}

private enum FirebaseKeyValidationResult {
    case success(String)
    case failure(String)
}

@MainActor
private final class SupabaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var selectedMode: FaxAuraMode?

    private let savedKeyStorage = "fax-aura.supabase.active-key"
    private let legacyKeyStorage = "fax-aura.firebase.active-key"
    private let modeStorage = "fax-aura.selected-mode"
    private let supabaseURL = "https://skarpahwcwkqdfxgtvlp.supabase.co"
    private let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrYXJwYWh3Y3drcWRmeGd0dmxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwMjc3NTYsImV4cCI6MjEwNzYwMzc1Nn0.PUh5QIs_W61En2PdyML31uzMFG_8NvCAHeRp1qYBzFw"

    func restore() async {
        let savedKey = UserDefaults.standard.string(forKey: savedKeyStorage)
            ?? UserDefaults.standard.string(forKey: legacyKeyStorage)
        guard let savedKey, !savedKey.isEmpty else { return }
        let result = await validate(savedKey)
        if case .success = result {
            isAuthorized = true
            if let savedMode = UserDefaults.standard.string(forKey: modeStorage) {
                selectedMode = FaxAuraMode(rawValue: savedMode)
            }
        } else {
            UserDefaults.standard.removeObject(forKey: savedKeyStorage)
            UserDefaults.standard.removeObject(forKey: legacyKeyStorage)
            UserDefaults.standard.removeObject(forKey: modeStorage)
            selectedMode = nil
            isAuthorized = false
        }
    }

    func activate(_ rawKey: String) async -> FirebaseKeyValidationResult {
        let normalized = rawKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else { return .failure("Escribe una key para continuar.") }
        let result = await validate(normalized)
        if case .success = result {
            UserDefaults.standard.set(normalized, forKey: savedKeyStorage)
            UserDefaults.standard.removeObject(forKey: legacyKeyStorage)
            isAuthorized = true
        }
        return result
    }

    func selectMode(_ mode: FaxAuraMode) {
        selectedMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: modeStorage)
    }

    private var deviceLabel: String {
        "\(UIDevice.current.model) · iOS \(UIDevice.current.systemVersion)"
    }

    private var deviceID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? deviceLabel
    }

    private func validate(_ key: String) async -> FirebaseKeyValidationResult {
        let hash = SHA256.hash(data: Data(key.utf8))
            .map { String(format: "%02x", $0) }
            .joined()
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else {
            return .failure("No se pudo preparar la conexión con Supabase.")
        }
        components.queryItems = [
            URLQueryItem(name: "select", value: "id,status,expires_at,device_id,device_label"),
            URLQueryItem(name: "key_hash", value: "eq.\(hash)")
        ]
        guard let url = components.url else {
            return .failure("No se pudo preparar la consulta de la key.")
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .failure("Supabase no está disponible en este momento.")
            }
            let records = try JSONDecoder().decode([SupabaseKeyRecord].self, from: data)
            guard let record = records.first else {
                return .failure("Key inválida o no registrada.")
            }
            if let status = record.status?.lowercased(), ["blocked", "disabled", "inactive", "revoked"].contains(status) {
                return .failure("Esta key está desactivada.")
            }
            if let expiration = record.expiresAtDate, expiration <= Date() {
                UserDefaults.standard.removeObject(forKey: "fax-aura.supabase.expires-at")
                return .failure("Esta key ya expiró.")
            }
            if let boundID = record.deviceID?.trimmingCharacters(in: .whitespacesAndNewlines),
               !boundID.isEmpty,
               boundID != deviceID {
                return .failure("Esta key ya está vinculada a otro dispositivo.")
            }
            if let boundLabel = record.deviceLabel?.trimmingCharacters(in: .whitespacesAndNewlines),
               !boundLabel.isEmpty,
               record.deviceID?.isEmpty != false,
               boundLabel != deviceLabel {
                return .failure("Esta key ya está vinculada a otro dispositivo.")
            }
            if let expiration = record.expiresAtDate {
                UserDefaults.standard.set(expiration.timeIntervalSince1970, forKey: "fax-aura.supabase.expires-at")
            } else {
                UserDefaults.standard.removeObject(forKey: "fax-aura.supabase.expires-at")
            }
            await updateDevice(forHash: hash, isFirstActivation: record.deviceID?.isEmpty != false)
            return .success("Key válida en Supabase")
        } catch {
            return .failure("No se pudo conectar con Supabase. Revisa tu conexión.")
        }
    }

    private func updateDevice(forHash hash: String, isFirstActivation: Bool) async {
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else { return }
        components.queryItems = [URLQueryItem(name: "key_hash", value: "eq.\(hash)")]
        guard let url = components.url else { return }
        let now = ISO8601DateFormatter().string(from: Date())
        var payload: [String: String] = [
            "device_id": deviceID,
            "device_label": deviceLabel,
            "last_seen_at": now
        ]
        if isFirstActivation { payload["first_seen_at"] = now }
        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=minimal", forHTTPHeaderField: "Prefer")
        _ = try? await URLSession.shared.data(for: request)
    }

}

private struct SupabaseKeyRecord: Decodable {
    let id: Int?
    let status: String?
    let expiresAt: String?
    let deviceID: String?
    let deviceLabel: String?

    enum CodingKeys: String, CodingKey {
        case id, status
        case expiresAt = "expires_at"
        case deviceID = "device_id"
        case deviceLabel = "device_label"
    }

    var expiresAtDate: Date? {
        guard let expiresAt else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: expiresAt) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: expiresAt)
    }
}

private struct FirebaseAuraModeSelectionView: View {
    let onSelect: (FaxAuraMode) -> Void

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(white: 0.16), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.white.opacity(0.13))
                .frame(width: 300, height: 300)
                .blur(radius: 80)
                .offset(y: -180)

            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    AppLogo(size: 34)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA")
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .tracking(1.5)
                            .foregroundStyle(Color.white.opacity(0.95))
                        Text("PRIVATE ACCESS")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(.white).frame(width: 7, height: 7).shadow(color: .white, radius: 4)
                        Text("ONLINE")
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)

                ZStack {
                    Color.black
                    Image("ActivityHeaderArt")
                        .resizable()
                        .aspectRatio(3.0, contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                    .frame(maxWidth: .infinity)
                    .frame(height: 132)
                    .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 19, style: .continuous)
                            .stroke(Color.white.opacity(0.72), lineWidth: 1.2)
                    )
                    .shadow(color: .white.opacity(0.42), radius: 16)
                    .padding(.horizontal, 12)

                VStack(spacing: 20) {
                    HStack(spacing: 13) {
                        Image("FreeFireLogo")
                            .resizable()
                            .scaledToFill()
                             .frame(width: 52, height: 52)
                            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.white.opacity(0.60), lineWidth: 1))
                            .shadow(color: .white.opacity(0.22), radius: 7)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("FREE FIRE")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .tracking(1.0)
                                .foregroundStyle(.white)
                            Text("NORMAL PROFILE")
                                .font(.system(size: 10, weight: .black, design: .monospaced))
                                .foregroundStyle(Color.white.opacity(0.95))
                        }
                        Spacer()
                        Text("STABLE")
                            .font(.system(size: 8, weight: .black, design: .monospaced))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8)
                            .frame(height: 23)
                            .background(Color.white.opacity(0.10), in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.35), lineWidth: 1))
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: .white.opacity(0.45), radius: 6)
                    }
                    .padding(.horizontal, 18)
                    .frame(maxWidth: .infinity)
                     .frame(height: 72)
                    .background(
                        LinearGradient(colors: [Color.white.opacity(0.18), Color.white.opacity(0.06)], startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                    )
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.68), lineWidth: 1.2))

                    Text("SELECT GAME MODE")
                        .font(.system(size: 11, weight: .black, design: .monospaced))
                        .tracking(1.2)
                        .foregroundStyle(.secondary)

                    modeButton(.normal)
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 14)
            }
            .frame(maxWidth: 410)
            .background(
                LinearGradient(
                    colors: [Color.white.opacity(0.16), Color.white.opacity(0.08), Color.black.opacity(0.58)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 22, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.54), lineWidth: 1.0))
            .shadow(color: .white.opacity(0.32), radius: 26)
             .padding(10)
        }
    }

    private func modeButton(_ mode: FaxAuraMode) -> some View {
        Button { onSelect(mode) } label: {
            HStack(spacing: 15) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.18))
                    Image(systemName: mode.icon)
                        .font(.system(size: 18, weight: .black))
                        .foregroundStyle(Color.white.opacity(0.95))
                }
                 .frame(width: 40, height: 40)
                VStack(alignment: .leading, spacing: 4) {
                    Text(mode.title)
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(mode.subtitle)
                        .font(.subheadline)
                    Text("PROFILE READY / SAFE MODE")
                        .font(.system(size: 8, weight: .black, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HStack(spacing: 5) {
                    Text("ENTER")
                        .font(.system(size: 8, weight: .black, design: .monospaced))
                    Image(systemName: "arrow.right")
                        .font(.system(size: 10, weight: .black))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .frame(height: 28)
                .background(Color.white.opacity(0.82), in: Capsule())
            }
             .padding(.horizontal, 12)
            .frame(maxWidth: .infinity)
             .frame(height: 78)
            .background(
                LinearGradient(colors: [Color.white.opacity(0.19), Color.white.opacity(0.075)], startPoint: .leading, endPoint: .trailing),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.72), lineWidth: 1.2))
            .shadow(color: .white.opacity(0.18), radius: 10, y: 3)
        }
        .buttonStyle(.plain)
    }
}

private struct FirebaseKeyActivationView: View {
    @State private var key = ""
    @State private var showKey = false
    @State private var message = ""
    @State private var isLoading = false
    let onActivate: (String) async -> FirebaseKeyValidationResult

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(white: 0.025), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 14) {
                HStack(spacing: 10) {
                    AppLogo(size: 38)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 13, weight: .black, design: .rounded)).tracking(1.8).foregroundStyle(.white)
                        Text("PRIVATE CONTROL CENTER").font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(0.7).foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(.white).frame(width: 7, height: 7).shadow(color: .white, radius: 4)
                        Text("SYSTEM ONLINE").font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.secondary)
                    }
                }
                 .padding(.horizontal, 14).padding(.vertical, 12)
                ZStack(alignment: .bottomLeading) {
                    ZStack {
                        Color.black
                        Image("ActivityHeaderArt")
                            .resizable()
                            .aspectRatio(3.0, contentMode: .fit)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 120)
                    LinearGradient(colors: [Color.black.opacity(0.05), Color.black.opacity(0.92)], startPoint: .center, endPoint: .bottom)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 22, weight: .black, design: .rounded)).tracking(1.0)
                        Text("SECURE ACTIVATION PANEL").font(.system(size: 9, weight: .black, design: .monospaced)).tracking(0.8).foregroundStyle(.white)
                    }.foregroundStyle(.white) .padding(10)
                }
                 .frame(height: 120)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.72), lineWidth: 1.2))
                .shadow(color: .white.opacity(0.42), radius: 16)
                .padding(.horizontal, 12)
                VStack(alignment: .leading, spacing: 13) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("WELCOME BACK").font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1.4).foregroundStyle(.white)
                            Text("Enter your key").font(.system(size: 22, weight: .black, design: .rounded)).foregroundStyle(.white)
                        }
                        Spacer()
                        Image(systemName: "lock.shield.fill").font(.system(size: 20, weight: .bold)).foregroundStyle(.white.opacity(0.9)).shadow(color: .white.opacity(0.5), radius: 8)
                    }
                    Text("Unlock your private Fax Aura session.").font(.subheadline).foregroundStyle(.secondary)
                    HStack {
                        Text("ACCESS KEY").font(.system(size: 9, weight: .black, design: .monospaced)).tracking(1.1).foregroundStyle(.secondary)
                        Spacer()
                        Text("SECURE INPUT").font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.85))
                    }
                    .padding(.top, 5)
                    HStack(spacing: 10) {
                        Image(systemName: "lock.fill").font(.system(size: 15, weight: .bold)).foregroundStyle(.white).frame(width: 24)
                        Group {
                            if showKey { TextField("Enter your key", text: $key) }
                            else { SecureField("Enter your key", text: $key) }
                        }
                        .textInputAutocapitalization(.characters).autocorrectionDisabled().foregroundStyle(.white)
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash.fill" : "eye.fill").font(.system(size: 14, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                    }
                    .padding(.horizontal, 14) .frame(height: 46)
                    .background(LinearGradient(colors: [Color.white.opacity(0.12), Color.black.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.58), lineWidth: 1))
                    .shadow(color: .black.opacity(0.3), radius: 7, y: 3)
                    Button(action: activateKey) {
                        HStack {
                            if isLoading { ProgressView().tint(.white) }
                            Text(isLoading ? "CHECKING ACCESS..." : "INITIALIZE SESSION").font(.headline.weight(.black))
                            Spacer()
                            if !isLoading { Image(systemName: "arrow.right").font(.system(size: 14, weight: .bold)) }
                        }
                        .padding(.horizontal, 21).frame(maxWidth: .infinity) .frame(height: 56)
                        .background(Color.white.opacity(0.16), in: Capsule())
                        .overlay(Capsule().stroke(Color.white.opacity(0.88), lineWidth: 1.1))
                        .foregroundStyle(.white).shadow(color: .white.opacity(0.16), radius: 12, y: 4)
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    HStack(spacing: 8) {
                        Image(systemName: "shield.checkered")
                        Text("PROTECTED SESSION").font(.system(size: 9, weight: .black, design: .monospaced))
                        Spacer()
                        Text("FAX AURA").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.85))
                    }.foregroundStyle(.secondary).padding(.top, 5)
                    HStack(spacing: 6) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(.white.opacity(0.85))
                        Text("PROJECT CREATED BY")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundStyle(.secondary)
                        Text("SENSIAURA")
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .tracking(0.7)
                            .foregroundStyle(.white.opacity(0.95))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                    if !message.isEmpty {
                        Text(message).font(.caption.weight(.semibold)).foregroundStyle(.white).multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 8).background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                } .padding(14)
            }
             .frame(maxWidth: 360)
            .background(LinearGradient(colors: [Color(white: 0.16), Color(white: 0.045)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.54), lineWidth: 1.0))
            .shadow(color: .white.opacity(0.30), radius: 24) .padding(10)
        }
    }

    private func activateKey() {
        isLoading = true
        Task {
            let result = await onActivate(key)
            await MainActor.run {
                if case .failure(let error) = result { message = error }
                isLoading = false
            }
        }
    }
}
