import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var keySession = FirebaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = AppSection.installed.rawValue
        } else {
            initialTab = AppSection.home.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: AppSection.installed.rawValue))
#endif
    }

    var body: some View {
        Group {
            if keySession.isAuthorized {
                if keySession.selectedMode != nil {
                    if horizontalSizeClass == .regular {
                        regularLayout
                    } else {
                        compactLayout
                    }
                } else {
                    FirebaseAuraModeSelectionView { mode in
                        keySession.selectMode(mode)
                    }
                }
            } else {
                FirebaseKeyActivationView { key in
                    await keySession.activate(key)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .task {
            await keySession.restore()
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Fax Aura")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .installed
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .installed: return "tab.installed"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .installed: return "tray.full.fill"
        }
    }
}


private enum FaxAuraMode: String {
    case ffMax = "ff-max"
    case normal = "normal"

    var title: String {
        switch self {
        case .ffMax: return "FF Max"
        case .normal: return "Normal"
        }
    }

    var subtitle: String {
        switch self {
        case .ffMax: return "Perfil de máximo rendimiento"
        case .normal: return "Perfil equilibrado y estable"
        }
    }

    var icon: String {
        switch self {
        case .ffMax: return "bolt.fill"
        case .normal: return "checkmark.circle.fill"
        }
    }
}

private enum FirebaseKeyValidationResult {
    case success(String)
    case failure(String)
}

@MainActor
private final class FirebaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var selectedMode: FaxAuraMode?
    private let savedKeyStorage = "fax-aura.firebase.active-key"
    private let databaseURL = "https://aimforge-331a9-default-rtdb.firebaseio.com"
    private let keysPath = "keys_sensi_red_exclusive"
    private let modeStorage = "fax-aura.selected-mode"

    func restore() async {
        guard let savedKey = UserDefaults.standard.string(forKey: savedKeyStorage),
              !savedKey.isEmpty else { return }
        let result = await validate(savedKey)
        if case .success = result {
            isAuthorized = true
            if let savedMode = UserDefaults.standard.string(forKey: modeStorage) {
                selectedMode = FaxAuraMode(rawValue: savedMode)
            }
        } else {
            UserDefaults.standard.removeObject(forKey: savedKeyStorage)
        }
    }

    func activate(_ rawKey: String) async -> FirebaseKeyValidationResult {
        let normalized = rawKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else { return .failure("Escribe una key para continuar.") }
        let result = await validate(normalized)
        if case .success = result {
            UserDefaults.standard.set(normalized, forKey: savedKeyStorage)
            isAuthorized = true
        }
        return result
    }

    func selectMode(_ mode: FaxAuraMode) {
        selectedMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: modeStorage)
    }

    private func validate(_ key: String) async -> FirebaseKeyValidationResult {
        guard let encodedKey = key.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "\(databaseURL)/\(keysPath)/\(encodedKey).json") else {
            return .failure("No se pudo preparar la conexión con Firebase.")
        }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .failure("Firebase no está disponible en este momento.")
            }
            guard let record = try? JSONDecoder().decode(FirebaseKeyRecord.self, from: data) else {
                return .failure("Key inválida o no registrada.")
            }
            if let status = record.status?.uppercased(), ["REVOKED", "DISABLED", "INACTIVE", "BLOCKED"].contains(status) {
                return .failure("Esta key está desactivada.")
            }
            if let expiration = record.expiration, !expiration.isPermanent, expiration.timestamp < Date().timeIntervalSince1970 * 1000 {
                return .failure("Esta key ya expiró.")
            }
            return .success("Key válida")
        } catch {
            return .failure("No se pudo conectar con Firebase. Revisa tu conexión.")
        }
    }
}

private struct FirebaseKeyRecord: Decodable {
    let status: String?
    let expiration: FirebaseExpiration?
}

private struct FirebaseExpiration: Decodable {
    let timestamp: Double
    let isPermanent: Bool

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let number = try? container.decode(Double.self) {
            timestamp = number
            isPermanent = false
            return
        }
        let string = try container.decode(String.self)
        if string.uppercased() == "PERMANENTE" || string.uppercased() == "PERMANENT" {
            timestamp = .greatestFiniteMagnitude
            isPermanent = true
        } else if let number = Double(string) {
            timestamp = number
            isPermanent = false
        } else {
            timestamp = 0
            isPermanent = false
        }
    }
}

private struct FirebaseAuraModeSelectionView: View {
    let onSelect: (FaxAuraMode) -> Void

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.13, green: 0.005, blue: 0.012), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 18) {
                Image("ActivityHeaderArt")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 118)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.red.opacity(0.65), lineWidth: 1))
                    .shadow(color: .red.opacity(0.4), radius: 14)
                Text("Selecciona tu modo")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.white)
                Text("Elige cómo quieres iniciar Fax Aura.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                VStack(spacing: 12) {
                    modeButton(.ffMax)
                    modeButton(.normal)
                }
            }
            .padding(24)
            .frame(maxWidth: 390)
            .background(
                LinearGradient(colors: [Color.white.opacity(0.09), Color.red.opacity(0.06), Color.black.opacity(0.3)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: 24, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.red.opacity(0.45), lineWidth: 1.2))
            .shadow(color: .red.opacity(0.24), radius: 22)
            .padding(24)
        }
    }

    private func modeButton(_ mode: FaxAuraMode) -> some View {
        Button { onSelect(mode) } label: {
            HStack(spacing: 14) {
                Image(systemName: mode.icon)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.red)
                    .frame(width: 42, height: 42)
                    .background(Color.red.opacity(0.13), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(mode.title)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                    Text(mode.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.red.opacity(0.9))
            }
            .padding(.horizontal, 15)
            .frame(height: 70)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.red.opacity(0.45), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

private struct FirebaseKeyActivationView: View {
    @State private var key = ""
    @State private var message = ""
    @State private var isLoading = false
    let onActivate: (String) async -> FirebaseKeyValidationResult

    var body: some View {
        ZStack {
            Circle()
                .fill(Color.red.opacity(0.12))
                .frame(width: 280, height: 280)
                .blur(radius: 70)
                .offset(x: 145, y: -260)
            Circle()
                .fill(Color.red.opacity(0.08))
                .frame(width: 230, height: 230)
                .blur(radius: 60)
                .offset(x: -150, y: 300)
            LinearGradient(
                colors: [Color.black, Color(red: 0.12, green: 0.005, blue: 0.012), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 15) {
                HStack {
                    Label("FAX AURA", systemImage: "bolt.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.red.opacity(0.95))
                    Spacer()
                    HStack(spacing: 6) {
                        Circle()
                            .fill(Color.green)
                            .frame(width: 7, height: 7)
                            .shadow(color: .green, radius: 4)
                        Text("SECURE ACCESS")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                }
                Image("ActivityHeaderArt")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 132)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(Color.red.opacity(0.72), lineWidth: 1.2)
                    )
                    .shadow(color: .red.opacity(0.48), radius: 16)
                    .accessibilityHidden(true)
                HStack(spacing: 8) {
                    Image(systemName: "lock.shield.fill")
                        .font(.system(size: 18, weight: .bold))
                    Text("ACCESO PROTEGIDO")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(1.1)
                }
                    .foregroundStyle(Color.red.opacity(0.95))
                    .padding(.horizontal, 13)
                    .frame(height: 32)
                    .background(Color.red.opacity(0.12), in: Capsule())
                    .overlay(Capsule().stroke(Color.red.opacity(0.35), lineWidth: 1))
                Text("Fax Aura")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Activa tu sesión")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)
                Text("Introduce tu key para continuar.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                HStack(spacing: 8) {
                    Rectangle()
                        .fill(Color.red.opacity(0.45))
                        .frame(height: 1)
                    Text("KEY DE ACCESO")
                        .font(.system(size: 9, weight: .bold, design: .monospaced))
                        .foregroundStyle(.secondary)
                    Rectangle()
                        .fill(Color.red.opacity(0.45))
                        .frame(height: 1)
                }
                .padding(.top, 2)
                SecureField("Key de acceso", text: $key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 15)
                    .frame(height: 54)
                    .background(
                        LinearGradient(
                            colors: [Color.white.opacity(0.12), Color.red.opacity(0.08)],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
                    )
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.red.opacity(0.62), lineWidth: 1))
                    .shadow(color: .red.opacity(0.14), radius: 10)
                    .foregroundStyle(.white)
                Button {
                    isLoading = true
                    Task {
                        let result = await onActivate(key)
                        await MainActor.run {
                            if case .failure(let error) = result { message = error }
                            isLoading = false
                        }
                    }
                } label: {
                    HStack {
                        if isLoading { ProgressView().tint(.white) }
                        Text(isLoading ? "Validando..." : "Activar key")
                            .font(.headline.weight(.bold))
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(
                        LinearGradient(colors: [Color.red, Color(red: 0.55, green: 0.01, blue: 0.02)], startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
                    )
                    .foregroundStyle(.white)
                    .shadow(color: .red.opacity(0.42), radius: 12, y: 4)
                }
                .buttonStyle(.plain)
                .disabled(isLoading || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.red.opacity(0.95))
                        .multilineTextAlignment(.center)
                }
            }
            .padding(26)
            .frame(maxWidth: 390)
            .background(
                LinearGradient(
                    colors: [Color.white.opacity(0.09), Color.red.opacity(0.06), Color.black.opacity(0.30)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 24, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.red.opacity(0.46), lineWidth: 1.2))
            .shadow(color: .red.opacity(0.25), radius: 22)
            .padding(24)
        }
    }
}
