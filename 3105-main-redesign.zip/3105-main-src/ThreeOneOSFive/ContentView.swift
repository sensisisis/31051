import SwiftUI
import UIKit
import CryptoKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var authSession = Main2SupabaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-new-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-sources-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-files-tab") {
            initialTab = 4
        } else if arguments.contains("--simulate-search-tab") {
            initialTab = 5
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if authSession.isAuthorized {
                if horizontalSizeClass == .regular {
                    regularLayout
                } else {
                    compactLayout
                }
            } else {
                Main2PasswordLoginView { password in
                    await authSession.activate(password: password)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
            Task { await authSession.restore() }
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .new:
            RepositoryNewView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .sources:
            RepositorySourcesView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession,
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .search:
            RepositorySearchView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .home
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .new: return "tab.new"
        case .sources: return "tab.sources"
        case .installed: return "tab.installed"
        case .files: return "tab.files"
        case .search: return "tab.search"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .new: return "clock.fill"
        case .sources: return "shippingbox.fill"
        case .installed: return "tray.full.fill"
        case .files: return "folder.fill"
        case .search: return "magnifyingglass"
        }
    }
}


private enum Main2AuthResult {
    case success
    case failure(String)
}

@MainActor
private final class Main2SupabaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    private let passwordHashStorage = "main2.supabase.active-password-hash"
    private let supabaseURL = "https://skarpahwcwkqdfxgtvlp.supabase.co"
    private let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrYXJwYWh3Y3drcWRmeGd0dmxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwMjc3NTYsImV4cCI6MjEwNzYwMzc1Nn0.PUh5QIs_W61En2PdyML31uzMFG_8NvCAHeRp1qYBzFw"

    func restore() async {
        guard let passwordHash = UserDefaults.standard.string(forKey: passwordHashStorage), !passwordHash.isEmpty else { return }
        if case .success = await validate(passwordHash: passwordHash) { isAuthorized = true }
        else { clear() }
    }

    func activate(password: String) async -> Main2AuthResult {
        let normalized = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return .failure("Enter your password.") }
        let passwordHash = hash(normalized)
        let result = await validate(passwordHash: passwordHash)
        if case .success = result {
            UserDefaults.standard.set(passwordHash, forKey: passwordHashStorage)
            isAuthorized = true
        }
        return result
    }

    private func clear() {
        UserDefaults.standard.removeObject(forKey: passwordHashStorage)
        isAuthorized = false
    }

    private func hash(_ value: String) -> String {
        SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    private var deviceID: String { UIDevice.current.identifierForVendor?.uuidString ?? "unknown-device" }
    private var deviceLabel: String { "\(UIDevice.current.model) · iOS \(UIDevice.current.systemVersion)" }

    private func validate(passwordHash: String) async -> Main2AuthResult {
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else { return .failure("Supabase connection error.") }
        components.queryItems = [
            URLQueryItem(name: "select", value: "id,key_hash,status,expires_at,device_id,device_label,password_hash"),
            URLQueryItem(name: "password_hash", value: "eq.\(passwordHash)")
        ]
        guard let url = components.url else { return .failure("Invalid Supabase request.") }
        var request = URLRequest(url: url)
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return .failure("Supabase is unavailable.") }
            let records = try JSONDecoder().decode([Main2SupabaseRecord].self, from: data)
            guard let record = records.first else { return .failure("Incorrect password.") }
            if let status = record.status?.lowercased(), ["blocked", "disabled", "inactive", "revoked"].contains(status) { return .failure("This password is disabled.") }
            if let expiration = record.expirationDate, expiration <= Date() { return .failure("This password has expired.") }
            if let bound = record.deviceID, !bound.isEmpty, bound != deviceID { return .failure("This password is linked to another device.") }
            guard let keyHash = record.keyHash, !keyHash.isEmpty else { return .failure("Supabase key record is incomplete.") }
            await updateDevice(keyHash: keyHash, firstActivation: record.deviceID?.isEmpty != false)
            return .success
        } catch { return .failure("Could not connect to Supabase.") }
    }

    private func updateDevice(keyHash: String, firstActivation: Bool) async {
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else { return }
        components.queryItems = [URLQueryItem(name: "key_hash", value: "eq.\(keyHash)")]
        guard let url = components.url else { return }
        let now = ISO8601DateFormatter().string(from: Date())
        var payload = ["device_id": deviceID, "device_label": deviceLabel, "last_seen_at": now]
        if firstActivation { payload["first_seen_at"] = now }
        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=minimal", forHTTPHeaderField: "Prefer")
        _ = try? await URLSession.shared.data(for: request)
    }
}

private struct Main2SupabaseRecord: Decodable {
    let keyHash: String?
    let status: String?
    let expiresAt: String?
    let deviceID: String?
    enum CodingKeys: String, CodingKey {
        case keyHash = "key_hash"
        case status
        case expiresAt = "expires_at"
        case deviceID = "device_id"
    }
    var expirationDate: Date? {
        guard let expiresAt else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: expiresAt) ?? {
            formatter.formatOptions = [.withInternetDateTime]
            return formatter.date(from: expiresAt)
        }()
    }
}

private struct Main2PasswordLoginView: View {
    @State private var password = ""
    @State private var showPassword = false
    @State private var message = ""
    @State private var loading = false
    let onSubmit: (String) async -> Main2AuthResult

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "lock.shield.fill").font(.system(size: 46, weight: .bold)).foregroundStyle(.red)
                Text("SECURE ACCESS").font(.system(size: 25, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text("Enter your password").foregroundStyle(.secondary)
                HStack {
                    Image(systemName: "lock.fill")
                    if showPassword { TextField("Password", text: $password) } else { SecureField("Password", text: $password) }
                    Button { showPassword.toggle() } label: { Image(systemName: showPassword ? "eye.slash" : "eye") }.buttonStyle(.plain)
                }
                .padding(.horizontal, 15).frame(height: 54).foregroundStyle(.red)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.red.opacity(0.55), lineWidth: 1))
                Button { submit() } label: {
                    HStack { if loading { ProgressView().tint(.white) }; Text(loading ? "CHECKING..." : "CONTINUE").fontWeight(.bold); Spacer(); Image(systemName: "arrow.right") }
                        .padding(.horizontal, 18).frame(maxWidth: .infinity).frame(height: 54).foregroundStyle(.white).background(Color.red, in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain).disabled(loading || password.isEmpty)
                if !message.isEmpty { Text(message).font(.footnote.weight(.semibold)).foregroundStyle(.red).multilineTextAlignment(.center) }
            }
            .padding(25).frame(maxWidth: 380).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.red.opacity(0.6), lineWidth: 1)).padding(20)
        }
    }
    private func submit() {
        loading = true
        Task { let result = await onSubmit(password); await MainActor.run { if case .failure(let error) = result { message = error }; loading = false } }
    }
}
