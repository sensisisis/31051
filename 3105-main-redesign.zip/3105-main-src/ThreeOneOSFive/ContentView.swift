import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var keySession = FirebaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = AppSection.installed.rawValue
        } else {
            initialTab = AppSection.home.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: AppSection.installed.rawValue))
#endif
    }

    var body: some View {
        Group {
            if keySession.isAuthorized {
                if horizontalSizeClass == .regular {
                    regularLayout
                } else {
                    compactLayout
                }
            } else {
                FirebaseKeyActivationView { key in
                    await keySession.activate(key)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .task {
            await keySession.restore()
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Fax Aura")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .installed
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .installed: return "tab.installed"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .installed: return "tray.full.fill"
        }
    }
}


private enum FirebaseKeyValidationResult {
    case success(String)
    case failure(String)
}

@MainActor
private final class FirebaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    private let savedKeyStorage = "fax-aura.firebase.active-key"
    private let databaseURL = "https://aimforge-331a9-default-rtdb.firebaseio.com"
    private let keysPath = "keys_sensi_red_exclusive"

    func restore() async {
        guard let savedKey = UserDefaults.standard.string(forKey: savedKeyStorage),
              !savedKey.isEmpty else { return }
        let result = await validate(savedKey)
        if case .success = result {
            isAuthorized = true
        } else {
            UserDefaults.standard.removeObject(forKey: savedKeyStorage)
        }
    }

    func activate(_ rawKey: String) async -> FirebaseKeyValidationResult {
        let normalized = rawKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else { return .failure("Escribe una key para continuar.") }
        let result = await validate(normalized)
        if case .success = result {
            UserDefaults.standard.set(normalized, forKey: savedKeyStorage)
            isAuthorized = true
        }
        return result
    }

    private func validate(_ key: String) async -> FirebaseKeyValidationResult {
        guard let encodedKey = key.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "\(databaseURL)/\(keysPath)/\(encodedKey).json") else {
            return .failure("No se pudo preparar la conexión con Firebase.")
        }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .failure("Firebase no está disponible en este momento.")
            }
            guard let record = try? JSONDecoder().decode(FirebaseKeyRecord.self, from: data) else {
                return .failure("Key inválida o no registrada.")
            }
            if let status = record.status?.uppercased(), ["REVOKED", "DISABLED", "INACTIVE", "BLOCKED"].contains(status) {
                return .failure("Esta key está desactivada.")
            }
            if let expiration = record.expiration, !expiration.isPermanent, expiration.timestamp < Date().timeIntervalSince1970 * 1000 {
                return .failure("Esta key ya expiró.")
            }
            return .success("Key válida")
        } catch {
            return .failure("No se pudo conectar con Firebase. Revisa tu conexión.")
        }
    }
}

private struct FirebaseKeyRecord: Decodable {
    let status: String?
    let expiration: FirebaseExpiration?
}

private struct FirebaseExpiration: Decodable {
    let timestamp: Double
    let isPermanent: Bool

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let number = try? container.decode(Double.self) {
            timestamp = number
            isPermanent = false
            return
        }
        let string = try container.decode(String.self)
        if string.uppercased() == "PERMANENTE" || string.uppercased() == "PERMANENT" {
            timestamp = .greatestFiniteMagnitude
            isPermanent = true
        } else if let number = Double(string) {
            timestamp = number
            isPermanent = false
        } else {
            timestamp = 0
            isPermanent = false
        }
    }
}

private struct FirebaseKeyActivationView: View {
    @State private var key = ""
    @State private var message = ""
    @State private var isLoading = false
    let onActivate: (String) async -> FirebaseKeyValidationResult

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.12, green: 0.005, blue: 0.012), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 18) {
                Image("ActivityHeaderArt")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 150)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(Color.red.opacity(0.72), lineWidth: 1.2)
                    )
                    .shadow(color: .red.opacity(0.48), radius: 16)
                    .accessibilityHidden(true)
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 36, weight: .bold))
                    .foregroundStyle(Color.red)
                    .shadow(color: .red.opacity(0.8), radius: 14)
                Text("Fax Aura")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Acceso protegido")
                    .font(.headline)
                    .foregroundStyle(.red.opacity(0.9))
                Text("Introduce tu key para activar la aplicación.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                SecureField("Key de acceso", text: $key)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 15)
                    .frame(height: 50)
                    .background(Color.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.red.opacity(0.55), lineWidth: 1))
                    .foregroundStyle(.white)
                Button {
                    isLoading = true
                    Task {
                        let result = await onActivate(key)
                        await MainActor.run {
                            if case .failure(let error) = result { message = error }
                            isLoading = false
                        }
                    }
                } label: {
                    HStack {
                        if isLoading { ProgressView().tint(.white) }
                        Text(isLoading ? "Validando..." : "Activar key")
                            .font(.headline.weight(.bold))
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(isLoading || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.red.opacity(0.95))
                        .multilineTextAlignment(.center)
                }
            }
            .padding(26)
            .frame(maxWidth: 390)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.red.opacity(0.38), lineWidth: 1.2))
            .shadow(color: .red.opacity(0.25), radius: 22)
            .padding(24)
        }
    }
}
