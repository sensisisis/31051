import SwiftUI
import UIKit
import Foundation
import CryptoKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @StateObject private var keySession = SupabaseKeySession()
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = AppSection.installed.rawValue
        } else {
            initialTab = AppSection.home.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: AppSection.installed.rawValue))
#endif
    }

    var body: some View {
        Group {
            if keySession.isAuthorized {
                if keySession.selectedMode != nil {
                    if horizontalSizeClass == .regular {
                        regularLayout
                    } else {
                        compactLayout
                    }
                } else {
                    FirebaseAuraModeSelectionView { mode in
                        keySession.selectMode(mode)
                    }
                }
            } else {
                FirebaseKeyActivationView { key in
                    await keySession.activate(key)
                }
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await keySession.restore() }
        }
        .task {
            await keySession.restore()
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
        .tint(Color(red: 0.95, green: 0.12, blue: 0.16))
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("Fax Aura")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            RepositoryHomeView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .installed
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .installed: return "tab.installed"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .installed: return "tray.and.arrow.down.fill"
        }
    }
}


private enum FaxAuraMode: String {
    case normal = "normal"

    var title: String { "Normal" }
    var subtitle: String { "Perfil estable de Free Fire" }
    var icon: String { "flame.fill" }
}

private enum FirebaseKeyValidationResult {
    case success(String)
    case failure(String)
}

@MainActor
private final class SupabaseKeySession: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var selectedMode: FaxAuraMode?

    private let savedKeyStorage = "fax-aura.supabase.active-key"
    private let legacyKeyStorage = "fax-aura.firebase.active-key"
    private let modeStorage = "fax-aura.selected-mode"
    private let supabaseURL = "https://skarpahwcwkqdfxgtvlp.supabase.co"
    private let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrYXJwYWh3Y3drcWRmeGd0dmxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwMjc3NTYsImV4cCI6MjEwNzYwMzc1Nn0.PUh5QIs_W61En2PdyML31uzMFG_8NvCAHeRp1qYBzFw"

    func restore() async {
        let savedKey = UserDefaults.standard.string(forKey: savedKeyStorage)
            ?? UserDefaults.standard.string(forKey: legacyKeyStorage)
        guard let savedKey, !savedKey.isEmpty else { return }
        let result = await validate(savedKey)
        if case .success = result {
            isAuthorized = true
            if let savedMode = UserDefaults.standard.string(forKey: modeStorage) {
                selectedMode = FaxAuraMode(rawValue: savedMode)
            }
        } else {
            UserDefaults.standard.removeObject(forKey: savedKeyStorage)
            UserDefaults.standard.removeObject(forKey: legacyKeyStorage)
            UserDefaults.standard.removeObject(forKey: modeStorage)
            selectedMode = nil
            isAuthorized = false
        }
    }

    func activate(_ rawKey: String) async -> FirebaseKeyValidationResult {
        let normalized = rawKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else { return .failure("Escribe una key para continuar.") }
        let result = await validate(normalized)
        if case .success = result {
            UserDefaults.standard.set(normalized, forKey: savedKeyStorage)
            UserDefaults.standard.removeObject(forKey: legacyKeyStorage)
            isAuthorized = true
        }
        return result
    }

    func selectMode(_ mode: FaxAuraMode) {
        selectedMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: modeStorage)
    }

    private var deviceLabel: String {
        "\(UIDevice.current.model) · iOS \(UIDevice.current.systemVersion)"
    }

    private var deviceID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? deviceLabel
    }

    private func validate(_ key: String) async -> FirebaseKeyValidationResult {
        let hash = SHA256.hash(data: Data(key.utf8))
            .map { String(format: "%02x", $0) }
            .joined()
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else {
            return .failure("No se pudo preparar la conexión con Supabase.")
        }
        components.queryItems = [
            URLQueryItem(name: "select", value: "id,status,expires_at,device_id,device_label"),
            URLQueryItem(name: "key_hash", value: "eq.\(hash)")
        ]
        guard let url = components.url else {
            return .failure("No se pudo preparar la consulta de la key.")
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                return .failure("Supabase no está disponible en este momento.")
            }
            let records = try JSONDecoder().decode([SupabaseKeyRecord].self, from: data)
            guard let record = records.first else {
                return .failure("Key inválida o no registrada.")
            }
            if let status = record.status?.lowercased(), ["blocked", "disabled", "inactive", "revoked"].contains(status) {
                return .failure("Esta key está desactivada.")
            }
            if let expiration = record.expiresAtDate, expiration <= Date() {
                return .failure("Esta key ya expiró.")
            }
            if let boundID = record.deviceID?.trimmingCharacters(in: .whitespacesAndNewlines),
               !boundID.isEmpty,
               boundID != deviceID {
                return .failure("Esta key ya está vinculada a otro dispositivo.")
            }
            if let boundLabel = record.deviceLabel?.trimmingCharacters(in: .whitespacesAndNewlines),
               !boundLabel.isEmpty,
               record.deviceID?.isEmpty != false,
               boundLabel != deviceLabel {
                return .failure("Esta key ya está vinculada a otro dispositivo.")
            }
            await updateDevice(forHash: hash, isFirstActivation: record.deviceID?.isEmpty != false)
            return .success("Key válida en Supabase")
        } catch {
            return .failure("No se pudo conectar con Supabase. Revisa tu conexión.")
        }
    }

    private func updateDevice(forHash hash: String, isFirstActivation: Bool) async {
        guard var components = URLComponents(string: "\(supabaseURL)/rest/v1/Aura") else { return }
        components.queryItems = [URLQueryItem(name: "key_hash", value: "eq.\(hash)")]
        guard let url = components.url else { return }
        let now = ISO8601DateFormatter().string(from: Date())
        var payload: [String: String] = [
            "device_id": deviceID,
            "device_label": deviceLabel,
            "last_seen_at": now
        ]
        if isFirstActivation { payload["first_seen_at"] = now }
        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=minimal", forHTTPHeaderField: "Prefer")
        _ = try? await URLSession.shared.data(for: request)
    }

}

private struct SupabaseKeyRecord: Decodable {
    let id: Int?
    let status: String?
    let expiresAt: String?
    let deviceID: String?
    let deviceLabel: String?

    enum CodingKeys: String, CodingKey {
        case id, status
        case expiresAt = "expires_at"
        case deviceID = "device_id"
        case deviceLabel = "device_label"
    }

    var expiresAtDate: Date? {
        guard let expiresAt else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: expiresAt) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: expiresAt)
    }
}

private struct FirebaseAuraModeSelectionView: View {
    let onSelect: (FaxAuraMode) -> Void

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.13, green: 0.005, blue: 0.012), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 18) {
                Image("ActivityHeaderArt")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 118)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.red.opacity(0.65), lineWidth: 1))
                    .shadow(color: .red.opacity(0.4), radius: 14)
                HStack(spacing: 10) {
                    Image("FreeFireLogo")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 42, height: 42)
                        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).stroke(Color.red.opacity(0.55), lineWidth: 1))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("FREE FIRE")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .tracking(1.2)
                            .foregroundStyle(.white)
                        Text("NORMAL MODE")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(.red.opacity(0.9))
                    }
                    Spacer()
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(.green)
                }
                .padding(.horizontal, 16)
                .frame(height: 64)
                .background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.red.opacity(0.5), lineWidth: 1))
                Text("Modo disponible")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
                modeButton(.normal)
            }
            .padding(24)
            .frame(maxWidth: 390)
            .background(
                LinearGradient(colors: [Color.white.opacity(0.09), Color.red.opacity(0.06), Color.black.opacity(0.3)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: 24, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.red.opacity(0.45), lineWidth: 1.2))
            .shadow(color: .red.opacity(0.24), radius: 22)
            .padding(24)
        }
    }

    private func modeButton(_ mode: FaxAuraMode) -> some View {
        Button { onSelect(mode) } label: {
            HStack(spacing: 14) {
                Image(systemName: mode.icon)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.red)
                    .frame(width: 42, height: 42)
                    .background(Color.red.opacity(0.13), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(mode.title)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                    Text(mode.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.red.opacity(0.9))
            }
            .padding(.horizontal, 15)
            .frame(height: 70)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.red.opacity(0.45), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

private struct FirebaseKeyActivationView: View {
    @State private var key = ""
    @State private var showKey = false
    @State private var message = ""
    @State private var isLoading = false
    let onActivate: (String) async -> FirebaseKeyValidationResult

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(red: 0.12, green: 0.005, blue: 0.012), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 11, weight: .black, design: .rounded)).tracking(1.5).foregroundStyle(.red)
                        Text("SECURE ACCESS").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(.green).frame(width: 7, height: 7)
                        Text("ONLINE").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 20).padding(.vertical, 16)
                ZStack(alignment: .bottomLeading) {
                    Image("ActivityHeaderArt").resizable().scaledToFill().frame(maxWidth: .infinity).frame(height: 136).clipped()
                    LinearGradient(colors: [.clear, Color.black.opacity(0.88)], startPoint: .center, endPoint: .bottom)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FAX AURA").font(.system(size: 24, weight: .black, design: .rounded))
                        Text("EARLY ACCESS PANEL").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.red)
                    }.foregroundStyle(.white).padding(18)
                }
                .frame(height: 136)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.red.opacity(0.72), lineWidth: 1.2))
                .shadow(color: .red.opacity(0.42), radius: 16)
                .padding(.horizontal, 12)
                VStack(alignment: .leading, spacing: 12) {
                    Text("WELCOME BACK").font(.system(size: 10, weight: .black, design: .monospaced)).tracking(1.4).foregroundStyle(.red)
                    Text("Enter your key").font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.white)
                    Text("Unlock your private Fax Aura session.").font(.subheadline).foregroundStyle(.secondary)
                    Text("ACCESS KEY").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.secondary).padding(.top, 5)
                    HStack(spacing: 10) {
                        Image(systemName: "lock.fill").font(.system(size: 15, weight: .bold)).foregroundStyle(.red).frame(width: 24)
                        Group {
                            if showKey { TextField("Enter your key", text: $key) }
                            else { SecureField("Enter your key", text: $key) }
                        }
                        .textInputAutocapitalization(.characters).autocorrectionDisabled().foregroundStyle(.white)
                        Text("READY").font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.red)
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash.fill" : "eye.fill").font(.system(size: 14, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                    }
                    .padding(.horizontal, 14).frame(height: 56)
                    .background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.red.opacity(0.50), lineWidth: 1))
                    Button(action: activateKey) {
                        HStack {
                            if isLoading { ProgressView().tint(.white) }
                            Text(isLoading ? "VALIDATING..." : "CONTINUE").font(.headline.weight(.black))
                            Spacer()
                            if !isLoading { Image(systemName: "arrow.right").font(.system(size: 14, weight: .bold)) }
                        }
                        .padding(.horizontal, 18).frame(maxWidth: .infinity).frame(height: 54)
                        .background(Color.red, in: Capsule()).foregroundStyle(.white).shadow(color: .red.opacity(0.38), radius: 12, y: 4)
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    VStack(spacing: 9) {
                        HStack(spacing: 8) { Image(systemName: "gift.fill"); Text("GET FREE KEY").font(.system(size: 10, weight: .bold, design: .monospaced)); Spacer(); Image(systemName: "chevron.right").font(.caption) }.foregroundStyle(.white)
                        HStack(spacing: 8) { Image(systemName: "paperplane.fill"); Text("SUPPORT: FAX AURA").font(.system(size: 10, weight: .bold, design: .monospaced)); Spacer(); Image(systemName: "chevron.right").font(.caption) }.foregroundStyle(.secondary)
                    }.padding(.top, 8)
                    if !message.isEmpty {
                        Text(message).font(.caption.weight(.semibold)).foregroundStyle(.red).multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 8).background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }.padding(22)
            }
            .frame(maxWidth: 390)
            .background(LinearGradient(colors: [Color(red: 0.10, green: 0.09, blue: 0.10), Color(red: 0.12, green: 0.015, blue: 0.02)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.red.opacity(0.62), lineWidth: 1.2))
            .shadow(color: .red.opacity(0.30), radius: 24).padding(18)
        }
    }

    private func activateKey() {
        isLoading = true
        Task {
            let result = await onActivate(key)
            await MainActor.run {
                if case .failure(let error) = result { message = error }
                isLoading = false
            }
        }
    }
}
