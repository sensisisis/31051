import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum InstalledPalette {
    static let red = Color.white
    static let redBright = Color.white
    static let black = Color.black
    static let card = Color(white: 0.075)
    static let muted = Color(white: 0.20)
}

private enum PatchPackagePickerPolicy {
    // Use the broadest document type so Files does not hide .3105 files
    // whose provider reports a different UTI. PatchPackageStore validates
    // the actual package bytes after the user selects the file.
    static let allowedContentTypes: [UTType] = [.item]
    static let copiesSelectedDocument = true
}

private enum WallpaperPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "tendies") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
}

struct PatchProjectsView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var store: PatchProjectStore
    @State private var showCreate = false
    @State private var showImporter = false
    @State private var showWallpaperImporter = false
    @State private var searchText = ""
    @State private var activityStatus = "Sistema listo — esperando funciones"
    @State private var activityDetail = "Sin operaciones recientes"
    @State private var activityTint: Color = InstalledPalette.redBright
    @State private var activityGlowRotation: Double = 0
    @State private var wallpaperPackages: [WallpaperStagedPackage] = []
    @State private var wallpaperImportFeedback: WallpaperImportFeedback?
    @State private var wallpaperPendingDeletion: WallpaperStagedPackage?
    @State private var applyAlert: PatchStoreAlert?
    @State private var isApplying = false
    @State private var isImportingWallpapers = false
    @State private var avatarEnabled = false
    @State private var cacheStatus = "READY"
    @State private var externalEnabled = false
    @State private var selectedPatchSection = "Avatar"
    @State private var showSimulatedWallpaperDetail = false
    @State private var simulatedWallpaperDetailGate = OneShotPresentationGate()
    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var filteredItems: [PatchLibraryItem] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let sectionItems = store.items.filter { item in
            if selectedPatchSection == "External" {
                return item.origin?.repositoryName != "Avatar" && item.origin?.repositoryName != "Cache"
            }
            return item.origin?.repositoryName == selectedPatchSection
        }
        let matchingItems: [PatchLibraryItem]
        if query.isEmpty {
            matchingItems = sectionItems
        } else {
            matchingItems = sectionItems.filter { item in
                if item.packageURL.lastPathComponent.localizedCaseInsensitiveContains(query) {
                    return true
                }
                guard let project = item.project else { return false }
                if project.name.localizedCaseInsensitiveContains(query)
                    || project.author.localizedCaseInsensitiveContains(query) {
                    return true
                }
                guard item.canInspectContents else { return false }
                return project.allBundleIdentifiers.contains {
                        $0.localizedCaseInsensitiveContains(query)
                    }
                    || project.directories.contains {
                        $0.relativePath.localizedCaseInsensitiveContains(query)
                    }
                    || project.rules.contains {
                        $0.relativePath.localizedCaseInsensitiveContains(query)
                            || $0.replacementFilename.localizedCaseInsensitiveContains(query)
                    }
            }
        }
        return matchingItems.sorted { lhs, rhs in
            let left = optionSortKey(lhs)
            let right = optionSortKey(rhs)
            if left.0 != right.0 { return left.0 < right.0 }
            return left.1.localizedCaseInsensitiveCompare(right.1) == .orderedAscending
        }
    }

    private func optionSortKey(_ item: PatchLibraryItem) -> (Int, String) {
        let original = "\(item.project?.name ?? "") \(item.packageURL.lastPathComponent)"
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
        let normalized = original.replacingOccurrences(of: "+", with: " ")
        if normalized.contains("pescoco") && normalized.contains("alto") {
            return (60, "Aim 60%")
        }
        if normalized.contains("pescoco") && normalized.contains("antena") {
            return (70, "Headtricking 70%")
        }
        if normalized.contains("alto") && normalized.contains("100") {
            return (100, "Headtricking 100%")
        }
        if normalized.contains("alto") && normalized.contains("antena") {
            return (100, "Aim 100%")
        }
        return (999, item.project?.name ?? "")
    }

    private var filteredWallpaperPackages: [WallpaperStagedPackage] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return wallpaperPackages }
        return wallpaperPackages.filter {
            $0.displayName.localizedCaseInsensitiveContains(query)
        }
    }

    private var hasLocalContent: Bool {
        !store.items.isEmpty || !wallpaperPackages.isEmpty
    }

    private var hasSearchResults: Bool {
        !filteredItems.isEmpty || !filteredWallpaperPackages.isEmpty
    }

    private var activePatchCount: Int {
        filteredItems.filter { DevicePatchService.latestReceipt(projectID: $0.id) != nil }.count
    }

    init(
        onOpenSettings: @escaping () -> Void = {},
        onOpenLogs: @escaping () -> Void = {}
    ) {
        self.onOpenSettings = onOpenSettings
        self.onOpenLogs = onOpenLogs
#if targetEnvironment(simulator)
        _showCreate = State(
            initialValue: ProcessInfo.processInfo.arguments.contains("--simulate-patch-editor")
        )
#endif
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ZStack {
                    Color.black
                    Image("ActivityHeaderArt")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 96)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(Color.white.opacity(0.72), lineWidth: 1.2)
                )
                .shadow(color: .white.opacity(0.20), radius: 12, y: 1)
                .padding(.horizontal, 10)
                .padding(.top, 5)
                .accessibilityHidden(true)
                installedActivityCard
                    .padding(.horizontal, 10)
                    .padding(.top, 6)
                patchSectionTabs
                    .padding(.horizontal, 10)
                    .padding(.top, 7)
                HStack(spacing: 10) {
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(InstalledPalette.redBright)
                        .frame(width: 4, height: 23)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Funciones")
                            .font(.title3.weight(.bold))
                            .foregroundStyle(.white)
                        Text("PARCHES DISPONIBLES")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(InstalledPalette.redBright.opacity(0.85))
                    }
                    Spacer()
                    HStack(spacing: 6) {
                        Text("\(activePatchCount) activos")
                            .foregroundStyle(.white)
                        Text("•")
                            .foregroundStyle(.secondary)
                        Text("\(filteredItems.count) total")
                            .foregroundStyle(.white)
                    }
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .padding(.horizontal, 10)
                    .frame(height: 28)
                    .background(Color.white.opacity(0.07), in: Capsule())
                    .overlay(Capsule().stroke(InstalledPalette.redBright.opacity(0.48), lineWidth: 1))
                }
                .padding(.horizontal, 12)
                .padding(.top, 8)
                .padding(.bottom, 2)
                List {
                    if !hasLocalContent && (store.isBusy || isImportingWallpapers) {
                        loadingState
                            .listRowSeparator(.hidden)
                    } else if !hasLocalContent {
                        emptyState
                            .listRowSeparator(.hidden)
                    } else if !hasSearchResults && !store.isBusy {
                        searchEmptyState
                            .listRowSeparator(.hidden)
                    } else {
                        if !filteredItems.isEmpty {
                            Section {
                                ForEach(filteredItems) { item in
                                    itemRow(item)
                                        .listRowBackground(InstalledPalette.black)
                                        .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                                }
                                .onDelete { offsets in
                                    offsets.map { filteredItems[$0] }.forEach(store.delete)
                                }
                            }
                        }
                        if !filteredWallpaperPackages.isEmpty {
                            Section {
                                ForEach(filteredWallpaperPackages) { package in
                                    NavigationLink {
                                        InstalledWallpaperPackageDetailView(
                                            package: package,
                                            onApplied: reloadWallpaperPackages
                                        )
                                    } label: {
                                        wallpaperRow(package)
                                    }
                                    .swipeActions(
                                        edge: .trailing,
                                        allowsFullSwipe: false
                                    ) {
                                        Button(role: .destructive) {
                                            wallpaperPendingDeletion = package
                                        } label: {
                                            Label(
                                                language.text("common.delete"),
                                                systemImage: "trash"
                                            )
                                        }
                                    }
                                }
                            } header: {
                                Text(language.text("tab.wallpapers"))
                                    .foregroundStyle(InstalledPalette.redBright)
                                    .font(.caption.weight(.bold))
                            }
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .background(
                    LinearGradient(
                        colors: [InstalledPalette.black, Color(white: 0.018)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .listRowBackground(InstalledPalette.black)
                .listRowSeparator(.hidden)
                .environment(\.defaultMinListRowHeight, 0)
                .scrollDismissesKeyboard(.immediately)
            }
            .background(
                LinearGradient(
                    colors: [InstalledPalette.black, Color(white: 0.03), InstalledPalette.black],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
            )
            .preferredColorScheme(.dark)
            .tint(InstalledPalette.red)
            .navigationTitle(language.text("tab.installed"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 9) {
                        Button {
                            activityStatus = "Actualizando parches…"
                            activityDetail = "Recargando lista de funciones"
                            activityTint = InstalledPalette.redBright
                            store.reload()
                            activityStatus = "Parches actualizados"
                            activityDetail = "Lista recargada correctamente"
                            activityTint = .green
                        } label: {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(InstalledPalette.redBright)
                                .frame(width: 32, height: 30)
                                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                        }
                        .disabled(store.isBusy || isImportingWallpapers || isApplying)
                        .accessibilityLabel("Refresh Patches")

                        Menu {
                            Button { showCreate = true } label: {
                                Label(language.text("patch.new"), systemImage: "doc.badge.plus")
                            }
                            Button { showImporter = true } label: {
                                Label(language.text("patch.import"), systemImage: "square.and.arrow.down")
                            }
                            Button { showWallpaperImporter = true } label: {
                                Label(language.text("wallpaper.import"), systemImage: "photo.badge.plus")
                            }
                        } label: {
                            if store.isBusy || isImportingWallpapers {
                                ProgressView().tint(AppTheme.accent)
                            } else {
                                Image(systemName: "plus")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundStyle(InstalledPalette.redBright)
                                    .frame(width: 32, height: 30)
                                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                            }
                        }
                        .disabled(store.isBusy || isImportingWallpapers)
                        .accessibilityLabel(language.text("patch.add"))

                        Button(action: onOpenSettings) {
                            Image(systemName: "gearshape")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundStyle(InstalledPalette.redBright)
                                .frame(width: 32, height: 30)
                                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                        }
                        .accessibilityLabel(language.text("accessibility.open_settings"))
                    }
                    .padding(.horizontal, 7)
                    .padding(.vertical, 5)
                    .background(InstalledPalette.card, in: Capsule())
                    .overlay(Capsule().stroke(InstalledPalette.redBright.opacity(0.7), lineWidth: 1))
                    .shadow(color: InstalledPalette.redBright.opacity(0.18), radius: 10, y: 4)
                }
            }
            .sheet(isPresented: $showImporter) {
                FileDocumentPicker(
                    allowedContentTypes: PatchPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: PatchPackagePickerPolicy.copiesSelectedDocument,
                    allowsMultipleSelection: false,
                    onSelection: { result in
                        showImporter = false
                        if case .success(let urls) = result, let url = urls.first {
                            store.importPackage(at: url)
                        }
                    },
                    onCancel: {
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showCreate) {
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false
                ) { project, password in
                    store.create(project: project, password: password)
                }
            }
            .sheet(item: $draftCoordinator.request) { request in
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false,
                    initialDraft: request.draft
                ) { project, password in
                    store.create(project: project, password: password)
                    draftCoordinator.clear()
                }
            }
            .sheet(isPresented: $showWallpaperImporter) {
                FileDocumentPicker(
                    allowedContentTypes: WallpaperPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: true,
                    allowsMultipleSelection: true,
                    onSelection: { result in
                        showWallpaperImporter = false
                        if case .success(let urls) = result, !urls.isEmpty {
                            importWallpaperPackages(urls)
                        }
                    },
                    onCancel: {
                        showWallpaperImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .alert(item: $wallpaperImportFeedback) { feedback in
                Alert(
                    title: Text(language.text(feedback.titleKey)),
                    message: Text(feedback.message),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .alert(item: $wallpaperPendingDeletion) { package in
                Alert(
                    title: Text(language.text("wallpaper.delete_title")),
                    message: Text(language.text(
                        "wallpaper.delete_message",
                        package.displayName
                    )),
                    primaryButton: .destructive(
                        Text(language.text("common.delete"))
                    ) {
                        deleteWallpaperPackage(package)
                    },
                    secondaryButton: .cancel(Text(language.text("common.cancel")))
                )
            }
            .onAppear {
                reloadWallpaperPackages()
                consumeExternalImport()
#if targetEnvironment(simulator)
                if ProcessInfo.processInfo.arguments.contains(
                    "--simulate-wallpaper-detail"
                ), !wallpaperPackages.isEmpty,
                   simulatedWallpaperDetailGate.claim() {
                    DispatchQueue.main.async {
                        showSimulatedWallpaperDetail = true
                    }
                }
#endif
            }
            .navigationDestination(isPresented: $showSimulatedWallpaperDetail) {
                if let package = wallpaperPackages.first {
                    InstalledWallpaperPackageDetailView(
                        package: package,
                        onApplied: reloadWallpaperPackages
                    )
                }
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
            .alert(item: $applyAlert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
        }
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    private func wallpaperRow(_ package: WallpaperStagedPackage) -> some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: wallpaperSymbol, tint: AppTheme.accent)
            VStack(alignment: .leading, spacing: 3) {
                Text(package.displayName)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                InstalledContentKindBadge(kind: .wallpaper, language: language)
                Text(language.text(
                    "wallpaper.package_summary",
                    Int64(package.payload.descriptors.count),
                    ByteCountFormatter.string(
                        fromByteCount: package.payload.totalBytes,
                        countStyle: .file
                    )
                ))
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 14)
         .padding(.vertical, 8)
        .background(
            LinearGradient(
                colors: [InstalledPalette.card, Color(white: 0.06)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(InstalledPalette.redBright.opacity(0.62), lineWidth: 1.2))
        .shadow(color: InstalledPalette.redBright.opacity(0.12), radius: 8, y: 3)
    }

    private var wallpaperSymbol: String {
        if #available(iOS 18.0, *) {
            return "photo.on.rectangle.angled.fill"
        }
        return "photo.fill.on.rectangle.fill"
    }

    private func reloadWallpaperPackages() {
        wallpaperPackages = WallpaperPackageStore.packages()
    }

    private func deleteWallpaperPackage(_ package: WallpaperStagedPackage) {
        do {
            try WallpaperPackageStore.delete(package)
            reloadWallpaperPackages()
        } catch {
            wallpaperImportFeedback = WallpaperImportFeedback(
                titleKey: "wallpaper.operation_failed",
                message: wallpaperErrorMessage(error)
            )
        }
    }

    private func importWallpaperPackages(_ urls: [URL]) {
        guard !isImportingWallpapers else { return }
        isImportingWallpapers = true
        DispatchQueue.global(qos: .userInitiated).async {
            var imported = 0
            var failures: [String] = []
            for url in urls {
                do {
                    _ = try WallpaperPackageStore.importPackage(from: url)
                    imported += 1
                    log("wallpaper: staged \(url.lastPathComponent)")
                } catch {
                    failures.append(
                        "\(url.lastPathComponent): \(wallpaperErrorMessage(error))"
                    )
                    log("wallpaper: import rejected \(url.lastPathComponent)")
                }
            }
            DispatchQueue.main.async {
                isImportingWallpapers = false
                reloadWallpaperPackages()
                wallpaperImportFeedback = WallpaperImportFeedback(
                    titleKey: failures.isEmpty
                        ? "wallpaper.import_done_title"
                        : "wallpaper.import_result_title",
                    message: failures.isEmpty
                        ? language.text(
                            "wallpaper.import_done_message",
                            Int64(imported)
                        )
                        : failures.joined(separator: "\n")
                )
            }
        }
    }

    private func wallpaperErrorMessage(_ error: Error) -> String {
        if let wallpaperError = error as? WallpaperLabError {
            return language.text(wallpaperError.localizationKey)
        }
        return language.text("wallpaper.error.unknown")
    }

    private var installedActivityCard: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle()
                    .fill(InstalledPalette.redBright.opacity(0.28))
                     .frame(width: 34, height: 34)
                    .shadow(color: InstalledPalette.redBright.opacity(0.30), radius: 7)
                Image(systemName: "waveform.path.ecg")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(InstalledPalette.redBright)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("Registro de actividad")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                Text(activityStatus)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(activityTint)
                    .lineLimit(1)
                Text(activityDetail)
                    .font(.system(size: 11, weight: .regular))
                    .foregroundStyle(.secondary.opacity(0.90))
                    .lineLimit(1)
            }
            Spacer()
            Circle()
                .fill(activityTint)
                .frame(width: 9, height: 9)
                .shadow(color: activityTint, radius: 5)
        }
         .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(
            LinearGradient(
                colors: [
                    Color(white: 0.13),
                    InstalledPalette.card,
                    Color(white: 0.08)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
        )
        .overlay {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.white.opacity(0.42), lineWidth: 1.1)
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(
                        AngularGradient(
                            colors: [
                                .clear,
                                .white.opacity(0.12),
                                .white.opacity(0.92),
                                .white.opacity(0.9),
                                .white.opacity(0.18),
                                .clear
                            ],
                            center: .center,
                            angle: .degrees(activityGlowRotation)
                        ),
                        lineWidth: 2.4
                    )
                    .shadow(color: .white.opacity(0.42), radius: 7)
            }
        }
        .shadow(color: .white.opacity(0.18), radius: 10, y: 0)
        .onAppear {
            withAnimation(.linear(duration: 2.8).repeatForever(autoreverses: false)) {
                activityGlowRotation = 360
            }
        }
    }


    private func sectionIcon(for section: String) -> String {
        switch section {
        case "Avatar": return "person.crop.circle.fill"
        case "Cache": return "bolt.horizontal.circle.fill"
        default: return "link.circle.fill"
        }
    }

    private var patchSectionTabs: some View {
        HStack(spacing: 4) {
            ForEach(["Avatar", "Cache", "External"], id: \.self) { section in
                Button {
                    selectedPatchSection = section
                    activityStatus = "Sección \(section) seleccionada"
                    activityDetail = "Funciones de parche disponibles"
                    activityTint = InstalledPalette.redBright
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: sectionIcon(for: section))
                            .font(.system(size: 17, weight: .bold))
                        Text(section.uppercased())
                            .font(.system(size: 8, weight: .black, design: .monospaced))
                    }
                    .foregroundStyle(selectedPatchSection == section ? .white : .secondary)
                    .frame(maxWidth: .infinity)
                     .frame(height: 42)
                    .background(selectedPatchSection == section ? InstalledPalette.redBright.opacity(0.30) : Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(selectedPatchSection == section ? InstalledPalette.redBright.opacity(0.9) : Color.white.opacity(0.08), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(3)
        .background(Color.black.opacity(0.50), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(InstalledPalette.redBright.opacity(0.42), lineWidth: 1))
    }


    @ViewBuilder
    private func itemRow(_ item: PatchLibraryItem) -> some View {
        if item.isLocked {
            Button { store.requestUnlock(for: item) } label: {
                PatchProjectRow(item: item, language: language)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
        } else {
            let isActive = DevicePatchService.latestReceipt(projectID: item.id) != nil
            HStack(spacing: 10) {
                PatchProjectRow(item: item, language: language)

                VStack(spacing: 3) {
                    Text(isActive ? "ACTIVO" : "LISTO")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .foregroundStyle(isActive ? .green : .secondary)
                    Text(isActive ? "DESACTIVAR" : "ACTIVAR")
                        .font(.system(size: 7, weight: .bold, design: .monospaced))
                        .foregroundStyle(isActive ? Color.white.opacity(0.82) : InstalledPalette.redBright.opacity(0.9))
                    Toggle(isOn: Binding(
                    get: { isActive },
                    set: { enabled in
                        if enabled {
                            applyPatch(item)
                        } else {
                            restorePatch(item, allowChangedTargets: true)
                        }
                    }
                )) {
                    EmptyView()
                }
                .labelsHidden()
                .tint(isActive ? .white : InstalledPalette.red)
                .scaleEffect(0.98)
                .disabled(isApplying)
                    .accessibilityLabel(language.text("patch.apply"))
                }
                 .frame(width: 52)
            }
             .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(
                LinearGradient(
                    colors: isActive
                        ? [Color(white: 0.12), Color(white: 0.045)]
                        : [InstalledPalette.card, Color(white: 0.065)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .overlay(
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(isActive ? Color.white.opacity(0.72) : InstalledPalette.redBright.opacity(0.68), lineWidth: 1.2)
                    HStack {
                        RoundedRectangle(cornerRadius: 2, style: .continuous)
                            .fill(isActive ? Color.white : InstalledPalette.redBright)
                            .frame(width: 3)
                            .padding(.vertical, 9)
                        Spacer()
                    }
                }
            )
            .shadow(color: (isActive ? Color.white : InstalledPalette.red).opacity(0.20), radius: 8, y: 2)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
        }
    }

    private func restorePatch(_ item: PatchLibraryItem, allowChangedTargets: Bool = false) {
        guard let receipt = DevicePatchService.latestReceipt(projectID: item.id), !isApplying else { return }
        activityStatus = "Restaurando archivo…"
        activityDetail = item.project?.name ?? "Verificando respaldo"
        activityTint = InstalledPalette.redBright
        isApplying = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: allowChangedTargets
                )
                await MainActor.run {
                    store.reload()
                    isApplying = false
                    activityStatus = "Archivo restaurado"
                    activityDetail = item.project?.name ?? "Restauración completada"
                    activityTint = .green
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isApplying = false
                    activityStatus = "Error al restaurar"
                    activityDetail = item.project?.name ?? "Operación fallida"
                    activityTint = InstalledPalette.redBright
                    applyAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isApplying = false
                    activityStatus = "Error al restaurar"
                    activityDetail = item.project?.name ?? "Operación fallida"
                    activityTint = InstalledPalette.redBright
                    applyAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    private func applyPatch(_ item: PatchLibraryItem) {
        guard let baseProject = item.project, !isApplying else { return }
        activityStatus = "Validando parche…"
        activityDetail = "Verificando archivo · \(item.project?.name ?? "Función")"
        activityTint = InstalledPalette.redBright
        isApplying = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isApplying = false
                    activityStatus = "Parche verificado"
                    activityDetail = "Archivo aplicado · \(item.project?.name ?? "Función")"
                    activityTint = .green
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isApplying = false
                    activityStatus = "Error al aplicar"
                    activityDetail = item.project?.name ?? "Operación fallida"
                    activityTint = InstalledPalette.redBright
                    applyAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isApplying = false
                    activityStatus = "Error al aplicar"
                    activityDetail = item.project?.name ?? "Operación fallida"
                    activityTint = InstalledPalette.redBright
                    applyAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("installed.empty_title"))
                .font(.headline)
            Text(language.text("installed.empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button(language.text("patch.new")) { showCreate = true }
                .buttonStyle(.bordered)
                .controlSize(.large)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var loadingState: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(language.text("installed.loading"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("patch.search_empty"))
                .font(.headline)
            Text(language.text("patch.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct WallpaperImportFeedback: Identifiable {
    let id = UUID()
    let titleKey: String
    let message: String
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    private var displayName: String {
        let original = "\(item.project?.name ?? "") \(item.packageURL.lastPathComponent)"
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
        let normalized = original.replacingOccurrences(of: "+", with: " ")
        if normalized.contains("pescoco") && normalized.contains("antena") {
            return "Headtricking 70%"
        }
        if normalized.contains("pescoco") && normalized.contains("alto") {
            return "Aim 60%"
        }
        if normalized.contains("alto") && normalized.contains("antena") {
            return "Aim 100%"
        }
        if normalized.contains("alto") && normalized.contains("100") {
            return "Headtricking 100%"
        }
        return item.project?.name ?? language.text("patch.locked_project")
    }

    private var displaySubtitle: String {
        switch displayName {
        case "Aim 60%": return "Mira estable 60%"
        case "Aim 100%": return "Mira estable 100%"
        case "Headtricking 100%": return "Practice mode · 100%"
        case "Headtricking 70%": return "Protected option · Practice"
        default: return item.isLocked ? language.text("patch.tap_to_unlock") : "PRACTICE CONFIGURATION"
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Image("OptionCardArt")
                    .resizable()
                    .scaledToFill()
                LinearGradient(
                    colors: [Color.black.opacity(0.18), Color.black.opacity(0.74)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                Image(systemName: item.isLocked ? "lock.fill" : "shippingbox.fill")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .shadow(color: .black, radius: 3)
            }
             .frame(width: 34, height: 34)
            .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(InstalledPalette.redBright.opacity(0.72), lineWidth: 0.9))
            .shadow(color: InstalledPalette.redBright.opacity(0.18), radius: 5)
            VStack(alignment: .leading, spacing: 2) {
                Text(displayName)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(displaySubtitle)
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 12)
            if item.summary.isPasswordProtected {
                optionBadge("key.fill", title: "KEY")
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
            if item.project?.isPrivate == true {
                optionBadge("eye.slash.fill", title: "PRIV")
                    .accessibilityLabel(language.text("patch.private"))
            }
        }
        .padding(.horizontal, 2)
         .padding(.vertical, 4)
    }

    private func optionBadge(_ systemName: String, title: String) -> some View {
        HStack(spacing: 3) {
            Image(systemName: systemName)
                .font(.system(size: 9, weight: .bold))
            Text(title)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
        }
        .foregroundStyle(InstalledPalette.redBright)
        .padding(.horizontal, 6)
        .frame(height: 20)
        .background(InstalledPalette.redBright.opacity(0.14), in: Capsule())
        .overlay(Capsule().stroke(InstalledPalette.redBright.opacity(0.36), lineWidth: 0.8))
    }
}

private enum InstalledContentKind {
    case patch
    case wallpaper

    var localizationKey: String {
        switch self {
        case .patch: return "installed.kind.patch"
        case .wallpaper: return "installed.kind.wallpaper"
        }
    }

    var systemImage: String {
        switch self {
        case .patch: return "shippingbox.fill"
        case .wallpaper: return "photo.fill"
        }
    }
}

private struct InstalledContentKindBadge: View {
    let kind: InstalledContentKind
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: kind.systemImage)
                .accessibilityHidden(true)
            Text(language.text(kind.localizationKey))
        }
            .font(.caption2.weight(.semibold))
            .foregroundStyle(InstalledPalette.redBright)
            .padding(.horizontal, 8)
            .frame(height: 24)
            .background(InstalledPalette.redBright.opacity(0.16), in: Capsule())
            .overlay(Capsule().stroke(InstalledPalette.redBright.opacity(0.42), lineWidth: 0.7))
            .fixedSize()
            .accessibilityElement(children: .combine)
    }
}

struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    let request: PatchPasswordRequest
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.white)
                    }
                } footer: {
                    if let origin = request.origin {
                        Text(language.text(
                            "patch.password_repo_contact",
                            origin.repositoryName
                        ))
                    } else {
                        Text(language.text("patch.password_once_message"))
                    }
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchStorePresentationModifier: ViewModifier {
    @ObservedObject var store: PatchProjectStore

    func body(content: Content) -> some View {
        content
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { request in
                PatchUnlockView(store: store, request: request)
            }
    }
}

extension View {
    func patchStorePresentation(_ store: PatchProjectStore) -> some View {
        modifier(PatchStorePresentationModifier(store: store))
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showChangedRestoreConfirmation = false
    @State private var showResetConfirmation = false
    @State private var restoreChangedPaths: [String] = []
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                Section(language.text("patch.information")) {
                    if !project.author.isEmpty {
                        patchInfoRow(
                            label: language.text("patch.author"),
                            value: project.author
                        )
                    }
                    patchInfoRow(label: language.text("patch.privacy")) {
                        Label(
                            language.text(project.isPrivate
                                ? "patch.private"
                                : "patch.public"),
                            systemImage: project.isPrivate
                                ? "eye.slash.fill"
                                : "eye"
                        )
                        .foregroundStyle(project.isPrivate ? AppTheme.accent : Color.secondary)
                    }
                    if let origin = item.origin {
                        patchInfoRow(
                            label: language.text("repository.source"),
                            value: origin.repositoryName
                        )
                    }
                }

                if project.isPrivate && !item.canInspectContents {
                    Section {
                        VStack(spacing: 10) {
                            Image(systemName: "lock.shield.fill")
                                .font(.system(size: 30, weight: .medium))
                                .foregroundStyle(AppTheme.accent)
                            Text(language.text("patch.private_hidden_title"))
                                .font(.headline)
                            Text(language.text("patch.private_hidden_message"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                    }
                } else if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        apply()
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking || receipt != nil)

                    if receipt != nil {
                        Button {
                            showResetConfirmation = true
                        } label: {
                            resetActionLabel
                        }
                        .disabled(isWorking)

                        Button(role: .destructive) {
                            restore(allowChangedTargets: true)
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                disabledBackArrow
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject, item?.canInspectContents == true {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.reset_confirm_title"),
            isPresented: $showResetConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.reset"), role: .destructive) { resetToAppliedState() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.reset_confirm_message"))
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private var disabledBackArrow: some View {
        Image(systemName: "chevron.left")
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(.secondary.opacity(0.72))
            .frame(width: 38, height: 38)
            .background(Color.white.opacity(0.10), in: Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.10), lineWidth: 1))
            .accessibilityLabel("Regreso desactivado")
            .accessibilityHint("Esta flecha está desactivada")
            .accessibilityAddTraits(.isButton)
            .allowsHitTesting(false)
    }

    private var resetActionLabel: some View {
        HStack(spacing: 12) {
            Image(systemName: "arrow.counterclockwise.circle.fill")
                .font(.system(size: 20, weight: .bold))
            VStack(alignment: .leading, spacing: 2) {
                Text(language.text("patch.reset"))
                    .font(.system(size: 14, weight: .bold))
                Text("Restore the applied state")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
        }
        .foregroundStyle(Color.white)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 14)
        .frame(height: 58)
        .background(
            LinearGradient(colors: [Color.white.opacity(0.16), Color.white.opacity(0.06)], startPoint: .leading, endPoint: .trailing),
            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.58), lineWidth: 1))
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func patchInfoRow(
        label: String,
        value: String
    ) -> some View {
        patchInfoRow(label: label) {
            Text(value)
                .foregroundStyle(.primary)
        }
    }

    private func patchInfoRow<Content: View>(
        label: String,
        @ViewBuilder value: () -> Content
    ) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer(minLength: 16)
            value()
                .multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.subheadline)
        .padding(.vertical, 5)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2, item.canInspectContents {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private var changedRestoreMessage: String {
        guard item?.project?.isPrivate != true || item?.isAuthorCopy == true else {
            return language.text(
                "patch.restore_changed_private_message",
                Int64(restoreChangedPaths.count)
            )
        }
        var visiblePaths = restoreChangedPaths.prefix(5).joined(separator: "\n")
        if restoreChangedPaths.count > 5 {
            visiblePaths += "\n…"
        }
        return language.text(
            "patch.restore_changed_message",
            Int64(restoreChangedPaths.count),
            visiblePaths
        )
    }

    private func prepareRestore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let inspection = try DevicePatchService.inspectRestore(receipt: receipt)
                if inspection.changedTargets.isEmpty {
                    try DevicePatchService.restore(receipt: receipt)
                    await MainActor.run {
                        isWorking = false
                        actionAlert = PatchStoreAlert(
                            titleKey: "common.done",
                            messageKey: "patch.restored_message"
                        )
                    }
                } else {
                    await MainActor.run {
                        isWorking = false
                        restoreChangedPaths = inspection.changedTargets.map(\.displayPath)
                        showChangedRestoreConfirmation = true
                    }
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.restore"
                    )
                }
            }
        }
    }

    private func restore(allowChangedTargets: Bool) {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: allowChangedTargets
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    private func resetToAppliedState() {
        guard let receipt, let project = item?.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.resetToAppliedState(
                    receipt: receipt,
                    project: project
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.done",
                        messageKey: "patch.reset_message"
                    )
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.reset"
                    )
                }
            }
        }
    }

    private func privateErrorKey(for error: PatchPackageError) -> String {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationKey
        }
        return "patch.error.private_operation"
    }

    private func privateErrorArgument(for error: PatchPackageError) -> String? {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationArgument
        }
        return nil
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
