import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @AppStorage("fax-aura.supabase.expires-at")
    private var keyExpiresAt = 0.0
    @AppStorage("fax-aura.rgb.enabled") private var rgbLightingEnabled = false
    @AppStorage("fax-aura.rgb.hue") private var rgbHue = 0.58
    @AppStorage("fax-aura.rgb.intensity") private var rgbIntensity = 0.72
    @AppStorage("fax-aura.rgb.motion") private var rgbMotion = true
    @State private var showKeyInfo = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        AppLogo()

                        VStack(alignment: .leading, spacing: 3) {
                            Text("Fax Aura")
                                .font(.headline)
                            Text(language.text("common.version", appVersion))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(language.text("common.device")) {
                    LabeledContent(
                        language.text("dashboard.hardware_model"),
                        value: AppInfo.displayMachineName
                    )
                    LabeledContent(
                        language.text("settings.ios_version"),
                        value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))"
                    )
                }

                Section(language.text("settings.title")) {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                            .foregroundStyle(appState.isSupported ? Color.white : Color.white)
                    }
                }

                Section("ACCESS CONTROL") {
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        keyStatusCard(at: context.date)
                    }
                    .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                    .listRowBackground(Color.clear)
                }

                Section("AURA RGB DARK") {
                    Toggle("Enable LED lighting", isOn: $rgbLightingEnabled)

                    if rgbLightingEnabled {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("COLOR SPECTRUM")
                                    .font(.system(size: 10, weight: .black, design: .monospaced))
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Circle()
                                    .fill(rgbColor)
                                    .frame(width: 18, height: 18)
                                    .shadow(color: rgbColor, radius: 7)
                            }
                            Slider(value: $rgbHue, in: 0...1)
                                .tint(rgbColor)

                            HStack {
                                Text("INTENSITY")
                                    .font(.system(size: 10, weight: .black, design: .monospaced))
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Text(intensityLabel)
                                    .font(.system(size: 10, weight: .black, design: .monospaced))
                            }
                            Slider(value: $rgbIntensity, in: 0.15...1.0)
                                .tint(rgbColor)
                            Toggle("Animate glow", isOn: $rgbMotion)
                        }
                        .padding(.vertical, 4)
                    }
                } footer: {
                    Text("Adds a customizable LED accent to the Fax Aura console. Text remains white for readability.")
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black.opacity(0.92))
            .tint(AppTheme.accent)
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
            .alert("Access key", isPresented: $showKeyInfo) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("To replace this key, return to the activation screen and enter the new key.")
            }
            .onAppear {
                // English is the only exposed language for this build.
                languageCode = AppLanguage.english.rawValue
                cleanerEnabled = false
                developerModeEnabled = false
            }
        }
    }

    private func keyStatusCard(at date: Date) -> some View {
        let active = remainingSeconds(at: date) > 0

        return VStack(alignment: .leading, spacing: 15) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.white.opacity(0.18))
                    Image(systemName: "key.fill")
                        .font(.system(size: 21, weight: .black))
                        .foregroundStyle(.white)
                }
                .frame(width: 48, height: 48)
                .overlay(Circle().stroke(Color.white.opacity(0.42), lineWidth: 1))

                VStack(alignment: .leading, spacing: 4) {
                    Text("KEY CONTROL")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .tracking(1.1)
                        .foregroundStyle(.secondary)
                    HStack(spacing: 7) {
                        Text(active ? "ACTIVE SESSION" : "SESSION EXPIRED")
                            .font(.system(size: 17, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                        Circle()
                            .fill(active ? Color.white : Color.white)
                            .frame(width: 8, height: 8)
                            .shadow(color: active ? .green : .red, radius: 5)
                    }
                }

                Spacer()

                Button { showKeyInfo = true } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "plus")
                        Text("MANAGE")
                    }
                    .font(.system(size: 10, weight: .black, design: .monospaced))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 11)
                    .frame(height: 32)
                    .background(Color.white.opacity(0.88), in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.8), lineWidth: 1))
                    .shadow(color: .red.opacity(0.32), radius: 8)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Add or replace key")
            }

            VStack(alignment: .leading, spacing: 7) {
                Text("TIME REMAINING")
                    .font(.system(size: 10, weight: .black, design: .monospaced))
                    .tracking(1.2)
                    .foregroundStyle(.secondary)
                Text(countdownText(at: date))
                    .font(.system(size: 24, weight: .black, design: .monospaced))
                    .monospacedDigit()
                    .foregroundStyle(active ? Color.white : Color.white)
                    .minimumScaleFactor(0.65)
                    .lineLimit(1)
            }

            HStack(spacing: 8) {
                Capsule()
                    .fill(active ? Color.white : Color.white)
                    .frame(height: 4)
                    .shadow(color: active ? .green.opacity(0.7) : .red.opacity(0.7), radius: 5)
                Text(active ? "SECURE" : "EXPIRED")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundStyle(active ? .green : .red)
            }
        }
        .padding(17)
        .background(
            LinearGradient(
                colors: [Color.white.opacity(0.20), Color.black.opacity(0.36), Color.white.opacity(0.045)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 23, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 23, style: .continuous)
                .stroke(Color.white.opacity(0.62), lineWidth: 1.2)
        )
        .shadow(color: .red.opacity(0.24), radius: 17, y: 5)
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private var intensityLabel: String {
        "\(Int(rgbIntensity * 100))%"
    }

    private var rgbColor: Color {
        Color(hue: rgbHue, saturation: 0.86, brightness: 1.0)
    }

    private func remainingSeconds(at date: Date) -> Int {
        guard keyExpiresAt > 0 else { return 0 }
        return max(0, Int(Date(timeIntervalSince1970: keyExpiresAt).timeIntervalSince(date)))
    }

    private func countdownText(at date: Date) -> String {
        guard keyExpiresAt > 0 else { return "NO EXPIRY" }
        let total = remainingSeconds(at: date)
        guard total > 0 else { return "EXPIRED" }
        let days = total / 86_400
        let hours = (total % 86_400) / 3_600
        let minutes = (total % 3_600) / 60
        let seconds = total % 60
        return String(format: "%02dd %02dh %02dm %02ds", days, hours, minutes, seconds)
    }
}
