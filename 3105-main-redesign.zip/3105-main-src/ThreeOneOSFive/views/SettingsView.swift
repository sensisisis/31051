import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @AppStorage("fax-aura.supabase.expires-at")
    private var keyExpiresAt = 0.0
    @State private var showKeyInfo = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        AppLogo()

                        VStack(alignment: .leading, spacing: 3) {
                            Text("Fax Aura")
                                .font(.headline)
                            Text(language.text("common.version", appVersion))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(language.text("common.device")) {
                    LabeledContent(
                        language.text("dashboard.hardware_model"),
                        value: AppInfo.displayMachineName
                    )
                    LabeledContent(
                        language.text("settings.ios_version"),
                        value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))"
                    )
                }

                Section(language.text("settings.title")) {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                }

                Section("Access key") {
                    HStack(spacing: 12) {
                        Image(systemName: "key.fill")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)

                        VStack(alignment: .leading, spacing: 2) {
                            Text("Active key")
                                .font(.body.weight(.semibold))
                            Text("Supabase access")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Spacer()

                        TimelineView(.periodic(from: .now, by: 60)) { context in
                            Text(remainingDaysText(at: context.date))
                                .font(.caption.weight(.bold))
                                .foregroundStyle(remainingDays(at: context.date) > 0 ? .green : .red)
                                .multilineTextAlignment(.trailing)
                        }

                        Button {
                            showKeyInfo = true
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 15, weight: .bold))
                                .frame(width: 30, height: 30)
                                .background(AppTheme.accent.opacity(0.14), in: Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Add or replace key")
                    }
                }
            }
            .tint(AppTheme.accent)
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
            .alert("Access key", isPresented: $showKeyInfo) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("To replace this key, return to the activation screen and enter the new key.")
            }
            .onAppear {
                // English is the only exposed language for this build.
                languageCode = AppLanguage.english.rawValue
                cleanerEnabled = false
                developerModeEnabled = false
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func remainingDays(at date: Date) -> Int {
        guard keyExpiresAt > 0 else { return 0 }
        return max(0, Int(ceil((Date(timeIntervalSince1970: keyExpiresAt).timeIntervalSince(date)) / 86_400)))
    }

    private func remainingDaysText(at date: Date) -> String {
        guard keyExpiresAt > 0 else { return "No expiry" }
        let days = remainingDays(at: date)
        return days == 1 ? "1 day left" : "\(days) days left"
    }
}
