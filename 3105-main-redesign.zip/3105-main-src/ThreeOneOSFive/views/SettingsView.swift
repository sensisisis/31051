import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @AppStorage("fax-aura.supabase.expires-at")
    private var keyExpiresAt = 0.0
    @State private var showKeyInfo = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        AppLogo()

                        VStack(alignment: .leading, spacing: 3) {
                            Text("Fax Aura")
                                .font(.headline)
                            Text(language.text("common.version", appVersion))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(language.text("common.device")) {
                    LabeledContent(
                        language.text("dashboard.hardware_model"),
                        value: AppInfo.displayMachineName
                    )
                    LabeledContent(
                        language.text("settings.ios_version"),
                        value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))"
                    )
                }

                Section(language.text("settings.title")) {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                }

                Section("KEY") {
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        keyStatusCard(at: context.date)
                    }
                    .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                    .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black.opacity(0.92))
            .tint(AppTheme.accent)
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
            .alert("Access key", isPresented: $showKeyInfo) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("To replace this key, return to the activation screen and enter the new key.")
            }
            .onAppear {
                // English is the only exposed language for this build.
                languageCode = AppLanguage.english.rawValue
                cleanerEnabled = false
                developerModeEnabled = false
            }
        }
    }

    private func keyStatusCard(at date: Date) -> some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.red.opacity(0.16))
                Image(systemName: "key.fill")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(Color.red.opacity(0.95))
            }
            .frame(width: 52, height: 52)
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.red.opacity(0.42), lineWidth: 1)
            )

            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 7) {
                    Text("ACTIVE KEY")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .tracking(0.8)
                        .foregroundStyle(.white)
                    Circle()
                        .fill(remainingSeconds(at: date) > 0 ? Color.green : Color.red)
                        .frame(width: 7, height: 7)
                        .shadow(color: remainingSeconds(at: date) > 0 ? .green : .red, radius: 4)
                }
                Text("TIME REMAINING")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            Text(countdownText(at: date))
                .font(.system(size: 13, weight: .black, design: .monospaced))
                .foregroundStyle(remainingSeconds(at: date) > 0 ? Color.green : Color.red)
                .monospacedDigit()
                .minimumScaleFactor(0.72)
                .lineLimit(1)

            Button {
                showKeyInfo = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 34, height: 34)
                    .background(
                        LinearGradient(
                            colors: [Color.red.opacity(0.95), Color.red.opacity(0.55)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        in: Circle()
                    )
                    .overlay(Circle().stroke(Color.red.opacity(0.75), lineWidth: 1))
                    .shadow(color: .red.opacity(0.35), radius: 8)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Add or replace key")
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 13)
        .background(
            LinearGradient(
                colors: [Color.red.opacity(0.18), Color.white.opacity(0.055), Color.black.opacity(0.22)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.red.opacity(0.58), lineWidth: 1.1)
        )
        .shadow(color: .red.opacity(0.18), radius: 13, y: 4)
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func remainingSeconds(at date: Date) -> Int {
        guard keyExpiresAt > 0 else { return 0 }
        return max(0, Int(Date(timeIntervalSince1970: keyExpiresAt).timeIntervalSince(date)))
    }

    private func countdownText(at date: Date) -> String {
        guard keyExpiresAt > 0 else { return "NO EXPIRY" }
        let total = remainingSeconds(at: date)
        guard total > 0 else { return "EXPIRED" }
        let days = total / 86_400
        let hours = (total % 86_400) / 3_600
        let minutes = (total % 3_600) / 60
        let seconds = total % 60
        return String(format: "%02dd %02dh %02dm %02ds", days, hours, minutes, seconds)
    }
}
